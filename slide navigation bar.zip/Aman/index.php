
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Profile</title>
    <link rel="shortcut icon" type="image/x-icon" href="logo.jpeg" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, user-scalable=no">
    <meta name="mobile-web-app-capable" content="yes">
    <link rel="stylesheet" type="text/css" media="screen" href="style.css" />
  
</head>
<body>
 
    
    
        <div class="overlay">
            <p>Hi, nice to meet you </p>
            <div class="button" onclick="openNav()">know more</div>
          <a href="https://github.com/Aman-Sharmaa/">Github</a>
            
            
<div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
    
   
</div>

<script>
function openNav() {
  document.getElementById("mySidenav").style.width = "100%";
}

function closeNav() {
  document.getElementById("mySidenav").style.width = "0";
}
</script>
    
    </div>
  
    <div class="sidenav">
    
    </div>
    
    
    <script>
    
     
    
    </script>

    
</body>
</html>


<?php 
 if(isset($_POST['submit'])){

    $yourname = $_POST['yourname'];
    $partnername = $_POST['partnername'];







    if($yourname && $partnername !== ""){
        echo "<center> your love meter is here </center>";



 // for A 

        if($yourname[0]=='a' ){
            if($partnername[0]=='a'){
                echo "<p>90%</p>";
              
            }
            elseif($partnername[0]=='b'){
                echo "<p>80%</p>";
               ;

            }
            elseif($partnername[0]=='c'){
                echo "<p>70%</p>";
                
            }
        }
        
     // for B
        if($yourname[0]=='b' ){
            if($partnername[0]=='a'){
                echo "<p>50%</p>";
               
                echo $yourname,"<br/>",$partnername;
            }
            elseif($partnername[0]=='b'){
                echo "<p>40%</p>";
                
                echo $yourname,"<br/>",$partnername;

            }
            elseif($partnername[0]=='c'){
                echo "<p>10%</p>";
               
                echo $yourname,"<br/>",$partnername;
            }
        }
 // for C
        if($yourname[0]=='c' ){
            if($partnername[0]=='a'){
                echo "<p>55%</p>";
               
                echo $yourname,"<br/>",$partnername;
            }
            elseif($partnername[0]=='b'){
                echo "<p>45%</p>";
                
                echo $yourname,"<br/>",$partnername;

            }
            elseif($partnername[0]=='c'){
                echo "<p>15%</p>";
               
                echo $yourname,"<br/>",$partnername;
            }
        }

//FOR D
        if($yourname[0]=='d' ){
            if($partnername[0]=='a'){
                echo "<p>35%</p>";
               
                echo $yourname,"<br/>",$partnername;
            }
            elseif($partnername[0]=='b'){
                echo "<p>25%</p>";
                
                echo $yourname,"<br/>",$partnername;

            }
            elseif($partnername[0]=='c'){
                echo "<p>85%</p>";
               
                echo $yourname,"<br/>",$partnername;
            }
        }

//FOR 
if($yourname[0]=='h' ){
    if($partnername[0]=='a'){
        echo "<p>15%</p>";
        echo "<p>kismat khrab hai</p>";
        
    }
    elseif($partnername[0]=='b'){
        echo "<p>5%</p>";
        echo "tu lodu hai";
        
        echo $yourname,"<br/>",$partnername;

    }
    elseif($partnername[0]=='c'){
        echo "<p>4%</p>";
        echo "kismat main nahi hai";
       
        echo $yourname,"<br/>",$partnername;
    }
}
        
    
    
    
    
    
    
    }

 
        
   
   
    



    
    











 
    }

?>