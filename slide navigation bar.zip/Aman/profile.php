
<?php 
 if(isset($_POST['submit'])){

    $yourname = $_POST['yourname'];
    $partnername = $_POST['partnername'];







    if($yourname && $partnername !== ""){
        echo "<center> your love meter is here </center>";



 // for A 

        if($yourname[0]=='a' ){
            if($partnername[0]=='a'){
                echo "<p>90%</p>";
              
            }
            elseif($partnername[0]=='b'){
                echo "<p>80%</p>";
               ;

            }
            elseif($partnername[0]=='c'){
                echo "<p>70%</p>";
                
            }
        }
        
     // for B
        if($yourname[0]=='b' ){
            if($partnername[0]=='a'){
                echo "<p>50%</p>";
               
                echo $yourname,"<br/>",$partnername;
            }
            elseif($partnername[0]=='b'){
                echo "<p>40%</p>";
                
                echo $yourname,"<br/>",$partnername;

            }
            elseif($partnername[0]=='c'){
                echo "<p>10%</p>";
               
                echo $yourname,"<br/>",$partnername;
            }
        }
 // for C
        if($yourname[0]=='c' ){
            if($partnername[0]=='a'){
                echo "<p>55%</p>";
               
                echo $yourname,"<br/>",$partnername;
            }
            elseif($partnername[0]=='b'){
                echo "<p>45%</p>";
                
                echo $yourname,"<br/>",$partnername;

            }
            elseif($partnername[0]=='c'){
                echo "<p>15%</p>";
               
                echo $yourname,"<br/>",$partnername;
            }
        }

//FOR D
        if($yourname[0]=='d' ){
            if($partnername[0]=='a'){
                echo "<p>35%</p>";
               
                echo $yourname,"<br/>",$partnername;
            }
            elseif($partnername[0]=='b'){
                echo "<p>25%</p>";
                
                echo $yourname,"<br/>",$partnername;

            }
            elseif($partnername[0]=='c'){
                echo "<p>85%</p>";
               
                echo $yourname,"<br/>",$partnername;
            }
        }

//FOR 
if($yourname[0]=='h' ){
    if($partnername[0]=='a'){
        echo "<p>15%</p>";
        echo "<p>kismat khrab hai</p>";
        
    }
    elseif($partnername[0]=='b'){
        echo "<p>5%</p>";
        echo "tu lodu hai";
        
        echo $yourname,"<br/>",$partnername;

    }
    elseif($partnername[0]=='c'){
        echo "<p>4%</p>";
        echo "kismat main nahi hai";
       
        echo $yourname,"<br/>",$partnername;
    }
}
        
    
    
    
    
    
    
    }

 
        
   
   
    



    
    











 
    }

?>